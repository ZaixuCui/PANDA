export MY_PATH=$PATH
source /data/aces/aces1/quarantines/Linux-i686/Feb-14-2008/init-sge.sh > /dev/null
export PATH=$PATH:$MY_PATH
export MINC_COMPRESS=0
unset MINC_FORCE_V2

