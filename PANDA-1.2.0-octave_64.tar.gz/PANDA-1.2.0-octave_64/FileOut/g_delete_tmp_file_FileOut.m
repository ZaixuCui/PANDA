
function [ FileOut ] = g_delete_tmp_file_FileOut( NiiOutputPath,NumberOfSubject_String )
%
% FileOut contains .done file is sign of the completion of the job
%

FileOut='';