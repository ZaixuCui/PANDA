
% This is just a flag of PANDA location.