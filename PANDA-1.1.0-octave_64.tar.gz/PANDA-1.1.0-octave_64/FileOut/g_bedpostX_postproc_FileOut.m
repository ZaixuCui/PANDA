function [ FileOut ] = g_bedpostX_postproc_FileOut( BedpostxFolder )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
FileOut{1} = [BedpostxFolder filesep 'BedpostX.done'];

